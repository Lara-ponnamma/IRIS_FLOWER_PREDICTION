from tkinter import*
import tkinter as tk
from PIL import Image, ImageTk

window = tk.Tk()
window.geometry("1000x1000")
window.title("FLOWER PREDICTION") 

Image = Image.open("flow.jpg")
photo = ImageTk.PhotoImage(Image)
mylabel = Label(image=photo).place(x=0,y=0)

l1 = tk.Label(text = "SEPAL LENGTH", bg = "black",fg = "white")
l1.place(x = 100,y = 50)
l2 = tk.Label(text = "SEPAL WIDTH", bg = "black",fg = "white")
l2.place(x = 100,y = 100)
l3 = tk.Label(text = "PETAL LENGTH", bg = "black",fg = "white")
l3.place(x = 100,y = 150)
l4 = tk.Label(text = "PETAL WIDTH", bg = "black",fg = "white")
l4.place(x = 100,y = 200)
l5 = tk.Label(text = "SPECIES", bg = "black",fg = "white")
l5.place(x = 100,y = 250)



text1 = tk.Entry()
text1.place(x= 400, y= 50)
text2 = tk.Entry()
text2.place(x= 400, y= 100)
text3 = tk.Entry()
text3.place(x= 400, y= 150)
text4 = tk.Entry()
text4.place(x= 400, y= 200)
text5 = tk.Entry()
text5.place(x= 400, y= 250)
text6 = tk.Entry(width = 50)
text6.place(x = 100,y=350)
def clear():
    text1.delete(0,END)
    text2.delete(0,END)
    text3.delete(0,END)
    text4.delete(0,END)
    text5.delete(0,END)
    text6.delete(0,END)


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder

from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score

df = pd.read_csv("D:\\EDA\\flower\\iris.csv")

le = LabelEncoder()
df['Species'] = le.fit_transform(df['Species'])

x = df[['SepalLengthCm','SepalWidthCm','PetalLengthCm','PetalWidthCm']]
y = df['Species']
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size = 0.20,random_state=1)

le = LogisticRegression()
le.fit(x_train,y_train)
y_pred = le.predict(x_test)

def predict():
    try:
        new = np.array([float(text1.get()), float(text2.get()), float(text3.get()), float(text4.get())])
        ans = le.predict([new])
        final = str(ans[0])
        text5.delete(0, "end")  # Clear previous content in text5
        text5.insert(0, final)  # Insert the prediction result
        if ans == 0:
            text6.insert(0,"FLOWER IS PREDICTED TO BE IRIS-SETOSA")
        elif ans == 1:
            text6.insert(0,"FLOWER IS PREDICTED TO BE IRIS-VERSICOLOUR")
        else:
            text6.insert(0,"FLOWER IS PREDICTED TO BE IRIS-VIRGINICA")

    except ValueError as e:
        print("Invalid input:", e)

        
accuracy = accuracy_score(y_test,y_pred)
print(accuracy)

confusion = confusion_matrix(y_test,y_pred)
print(confusion)

classification = classification_report(y_test,y_pred)
print(classification)


Button1 = tk.Button(text = 'CLEAR', command = clear, fg = 'white',bg = 'black').place(x = 250,y = 400)

Button2 = tk.Button(text = 'PREDICT', command = predict, fg = 'white',bg = 'black').place(x = 250,y = 450)

window.mainloop()



